package com.example.task2.network

data class post( val body: String,
                 val id: Int,
                 val title: String,
                 val userId: Int )